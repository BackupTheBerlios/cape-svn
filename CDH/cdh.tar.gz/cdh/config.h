/* 
 * File:   config.h
 * Author: matt
 *
 * Created on February 7, 2011, 5:13 PM
 */

#include <stdio.h>

#ifndef CONFIG_H
#define	CONFIG_H

void readConf(char*);
void readArgs(int,char**);

#endif	/* CONFIG_H */

